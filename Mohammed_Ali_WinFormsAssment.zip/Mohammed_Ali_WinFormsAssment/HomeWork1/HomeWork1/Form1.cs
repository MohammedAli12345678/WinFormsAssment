﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Text.RegularExpressions;
using System.Windows;
namespace HomeWork1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            email.Validating += new System.ComponentModel.CancelEventHandler(CheckEmail);
        }

        private void CheckEmail(object sender, System.ComponentModel.CancelEventArgs e)
        {

            string pattern = @"^[^@\s]+@[^@\s]+\.[^@\s]+$";

            if (!Regex.IsMatch(email.Text, pattern))
            {
                email.BackColor = System.Drawing.Color.LightPink;
                MessageBox.Show("Error in the Email");
                e.Cancel = true;

            }
            else
            {
                email.BackColor = System.Drawing.Color.White;
            }


            
        }
        private void Label1_Click(object sender, EventArgs e)
        {

        }
        
        private void Email_TextChanged(object sender, EventArgs e)
        {

        }

        private void Login_Click(object sender, EventArgs e)
        {
            string selectedGenger = "";
            if (radioButton1.Checked)
            {
                selectedGenger = "Male";
            }
            else if (radioButton2.Checked)
            {
                selectedGenger = "female";
            }
            else
                selectedGenger = "Other";

            DateTime selectDate = brithdate.Value;
            string slectedCountry = country.SelectedItem.ToString();

            MessageBox.Show("Name : " + name.Text + "\n"
                            + "Email : " + email.Text + "\n"
                            + "PassWord : " + pass.Text + "\n"
                            + "Genger  : " + selectedGenger + "\n"
                            + "DateBrith : " + selectDate.ToString("yyyy-MM-dd") + "\n"
                            + "Country : " + slectedCountry);
            
        }

        private void ColorChoose_Click(object sender, EventArgs e)
        {
            if (colorDialog1.ShowDialog() == DialogResult.OK)
            {
                this.BackColor = colorDialog1.Color;
                MessageBox.Show("Name of Color : "+colorDialog1.Color.Name);
            }
            
        }

        private void Brithdate_ValueChanged(object sender, EventArgs e)
        {

        }
    }
}
